<?php
require "../config/db.php";
$q=$conn->prepare("SELECT * FROM notifications WHERE user_id=? AND is_read=0");
$q->execute([$_SESSION['user_id']]);
echo json_encode($q->fetchAll());
?>