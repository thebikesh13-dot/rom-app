<?php
require "../config/db.php";
$conn->prepare("INSERT INTO instances(sender_id,receiver_id,type,message)
VALUES(?,?,?,?)")->execute([
 $_SESSION['user_id'],$_POST['receiver_id'],
 $_POST['type'],$_POST['message']
]);
$conn->prepare("INSERT INTO notifications(user_id,content)
VALUES(?,?)")->execute([
 $_POST['receiver_id'],
 $_SESSION['username']." sent you ".$_POST['type']
]);
?>