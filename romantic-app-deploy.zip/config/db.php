<?php
$conn = new PDO(
  "mysql:host=localhost;dbname=romantic_app;charset=utf8mb4",
  "root","",
  [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);
session_start();
?>