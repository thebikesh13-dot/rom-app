<?php
require "../config/db.php";
if($_SERVER['REQUEST_METHOD']=="POST"){
 $stmt=$conn->prepare("SELECT * FROM users WHERE username=?");
 $stmt->execute([$_POST['username']]);
 $u=$stmt->fetch();
 if($u && password_verify($_POST['password'],$u['password'])){
  $_SESSION['user_id']=$u['id'];
  $_SESSION['username']=$u['username'];
  header("Location: ../dashboard.php");
 }
}
?>
<form method="post">
<input name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<button>Login</button>
</form>