<?php
require "../config/db.php";
if($_SERVER['REQUEST_METHOD']=="POST"){
 $conn->prepare("INSERT INTO users(username,password,full_name)
 VALUES(?,?,?)")->execute([
 $_POST['username'],
 password_hash($_POST['password'],PASSWORD_DEFAULT),
 $_POST['name']
 ]);
 echo "Registered. <a href='login.php'>Login</a>";
}
?>
<form method="post">
<input name="name" placeholder="Name"><br>
<input name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<button>Register</button>
</form>