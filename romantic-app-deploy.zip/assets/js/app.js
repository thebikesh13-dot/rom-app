function send(type){
let msg=prompt("Message (optional)");
fetch("instances/send.php",{
method:"POST",
body:new URLSearchParams({
type:type,message:msg,receiver_id:PARTNER_ID
})
});
toast("Sent with love ❤️");
}
function toast(t){
let el=document.getElementById("toast");
el.innerText=t;el.style.display="block";
setTimeout(()=>el.style.display="none",3000);
}
setInterval(()=>{
fetch("notifications/fetch.php")
.then(r=>r.json())
.then(n=>{if(n.length)toast(n[0].content);});
},4000);