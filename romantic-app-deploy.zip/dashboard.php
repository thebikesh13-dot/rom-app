<!DOCTYPE html>
<html>
<head>
<title>Love Dashboard</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<h2>You & Your Partner 💖</h2>
<div class="actions">
<button onclick="send('💋 Kiss')">💋</button>
<button onclick="send('💭 Imagining You')">💭</button>
<button onclick="send('💞 Flying Kiss')">💞</button>
</div>
<div id="toast"></div>
<script>const PARTNER_ID=1;</script>
<script src="assets/js/app.js"></script>
</body>
</html>